package com.harshitandro.SmartHome;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.text.format.Formatter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class DataHandlerService extends Service {

    private static final int  WM_SERVER_ID = 0;
    private static final int  GM_SERVER_ID = 1;
    private static final int  EM_SERVER_ID = 2;

    private DatagramSocket broadcastSocket;
    private DatagramPacket broadcastPacket;
    private String broadcastMessage = "_SERVER_BCAST";
    private byte[] messageBuffer;


    int BROADCAST_PORT [] = {9000,9001,9002};

    ServerSocket server[] = new ServerSocket[3];

    Socket comSoc[] = new Socket[3];

    BufferedReader dataReader [] = new BufferedReader[3];

    ScheduledExecutorService executor= Executors.newScheduledThreadPool(3);

    public DataHandlerService() {}

    private String getServerName(int serverID){
        switch(serverID){
            case WM_SERVER_ID : return "WM";
            case GM_SERVER_ID : return "GM";
            case EM_SERVER_ID : return "EM";
            default           : return "UNREG";
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        try {
            broadcastSocket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        System.out.println(wm.getConnectionInfo());
        String localAddr = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        System.out.println("WIFI IP Addr:"+localAddr);
        for(int i =0;i<server.length;i++) {
            try {
                server[i] = new ServerSocket(0, 0, Inet4Address.getByName(localAddr));
                server[i].setSoTimeout(1000);
                System.out.println(server[i].getSoTimeout());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        for(int i = 0;i <3 ; i++) {
            int serverId = i;
            executor.schedule(() -> {
                try {
                    ScanHost(serverId, BROADCAST_PORT[serverId]);
                } catch (Exception e) {
                    System.err.println(getServerName(serverId) + ": Host Scan Timeout");
                    e.printStackTrace();
                }
            }, 0, TimeUnit.MILLISECONDS);
        }
    }




    private void ScanHost(int serverId,int BROADCAST_PORT){

        while(true) {
            System.out.println(getServerName(serverId)+" Scan Starting");
            try {
                messageBuffer = (getServerName(serverId)+broadcastMessage + ":" + server[serverId].getLocalPort()).getBytes("utf-8");
                broadcastPacket = new DatagramPacket(messageBuffer, messageBuffer.length, Inet4Address.getByName("255.255.255.255"), BROADCAST_PORT);
                broadcastSocket.setBroadcast(true);
                broadcastSocket.send(broadcastPacket);
                if(ConnectionCreator(serverId))
                    DataPooler(serverId);
                System.out.println("Scan host complete " + getServerName(serverId));
            }
            catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    private boolean ConnectionCreator(int serverID){
        try {
            comSoc[serverID] = server[serverID].accept();
            dataReader[serverID] = new BufferedReader(new InputStreamReader(comSoc[serverID].getInputStream()));
            System.out.println(getServerName(serverID)+"Server Found");
            Intent intent = new Intent("SERVER_FOUND_ACK");
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
            System.out.println("Connected to "+getServerName(serverID)+" at "+comSoc[serverID].getInetAddress());
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Destroyer from creator");
            ConnectionDestroyer(serverID);
            return false;
        }

    }

    private void DataPooler(int serverID) {
        String msg;
        try {
            System.out.println(getServerName(serverID)+"outer");
            while ( dataReader[serverID] != null  ) {
                System.out.println(getServerName(serverID)+"inner");
                msg = dataReader[serverID].readLine();
                System.out.println(getServerName(serverID)+ ": " +msg);
                if( msg == null){
                    ConnectionDestroyer(serverID);
                    return;
                }
                Intent intent = new Intent(getServerName(serverID) + "_DATA");
                intent.putExtra("TotalVal", msg.split(",")[0]);
                if (msg.split(",").length == 2)
                    intent.putExtra("InstantVal", msg.split(",")[1]);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
                System.out.println(getServerName(serverID)+" Bcast sent");
            }
        } catch (IOException e) {
            e.printStackTrace();
            ConnectionDestroyer(serverID);
        }
    }

    private void ConnectionDestroyer(int serverID){
        System.out.println("Destroyer "+getServerName(serverID));
        try {
                dataReader[serverID].close();
                comSoc[serverID].close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (NullPointerException e){
            e.printStackTrace();
        }
        finally {
            String msg1 = "SERVER_ERR";
            Intent intent = new Intent(getServerName(serverID) + "_DATA_ERR");
            intent.putExtra("ERR", msg1);
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
            comSoc[serverID] = null;
            dataReader[serverID] = null;
        }
    }
}
